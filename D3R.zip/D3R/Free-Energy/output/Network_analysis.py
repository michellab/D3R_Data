#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = "Antonia Mey"
__email__ = "antonia.mey@ed.ac.uk"


import numpy as np
import networkx as nx
import matplotlib.pylab as plt
import matplotlib
import seaborn as sns
import scipy.stats
import copy
import argparse
sns.set_style("ticks")
sns.set_context("notebook", font_scale = 2)


def symmetrize_graph(Set):
    for u,v,w in Set.edges(data=True):
        if not Set.has_edge(v,u):
            assymetric_w = -w['weight']
            assymetric_e = -w['error']
            Set.add_edge(v,u,weight=assymetric_w, error = assymetric_e)
    return Set

def save_average_paths(pathaverage, filename):
    f = open(filename, 'w')
    for d in pathaverage:
        for k,v in d.iteritems():
            if k == 'error':
                error = v
            else:
                r_energy_k = k
                r_energy_v = v
        f.write(str(r_energy_k)+', '+str(r_energy_v)+', '+str(error)+'\n')
    f.close()

def get_average_paths(Set, target_node):
    #Get all relative free energies with respect to node x
    pathaverage = []
    for n in Set.nodes():
        paths = nx.shortest_simple_paths(Set,target_node , n)
        err_list = []
        sum_list = []
        for p in paths:
            sum = 0
            error = 0.0
            for node in range(len(p)-1):
                sum= sum+ Set.get_edge_data(p[node], p[node+1])['weight']
                error = error+Set.get_edge_data(p[node], p[node+1])['error']**2
            sum_list.append(sum)
            err_list.append(error)
            error = np.sqrt(error)
            print r'DDG for path %s is %f +/- %f kcal/mol' %(p, sum, error)
        avg_sum = np.mean(np.array(sum_list))
        avg_err = np.mean(np.array(err_list))
        avg_std = np.std(np.array(sum_list))
        print ("Average sum for path to %s is %f " %(n,avg_sum))
        a = {str(n):avg_sum}
        a['error']=avg_std
        #a['error']=sqrt(avg_err)
        pathaverage.append(a)
        #avg_err = np.mean(np.array(err_list))
        print "================"
    return pathaverage

def get_cycles(Set):
    #cycle closure
    cyc = nx.simple_cycles(Set)
    for c in cyc:
        sum = 0
        error = 0
        if len(c)>2:
            sum = Set.get_edge_data(c[-1], c[0])['weight']
            error = (Set.get_edge_data(c[-1], c[0])['error'])**2
            for node in range(len(c)-1):
                sum= sum+ Set.get_edge_data(c[node], c[node+1])['weight']
                error = error +(Set.get_edge_data(c[node], c[node+1])['error'])**2
            error = np.sqrt(error)
            print 'DDG for cycle %s is %.2f ± %.2f kcal/mol' %(c,sum,error)


def calculatePI(series1, series2):
    sumwijcij = 0.0
    sumwij = 0.0

    keys = series1.keys()
    keys.sort()

    for i in range(0,len(keys)):
        keyi = keys[i]
        for j in range(i+1,len(keys)):
            keyj = keys[j]
            wij = abs(series1[keyj][0] - series1[keyi][0] )
            # print "series0 j %s series 0 i %s wij %s i %s j %s" % (series[0][j],series[0][i],wij,i,j)
            num =  (series1[keyj][0] - series1[keyi][0])
            den =  (series2[keyj][0] - series2[keyi][0] )
            #if den < 0.0001:
            #    den = 0.001
            #print num, den
            val = num / den
            # print val,serie[j],serie[i]
            if val > 0:
                cij = 1.0
            elif val < 0:
                cij = -1.0
            # print cij
            sumwijcij += wij*cij
            sumwij += wij
            # print i,j,series[0][j],serie[j],series[0][i],serie[i],val,wij*cij,wij
            # sys.exit(-1)
    PI = sumwijcij/sumwij
    #print PI
    return PI

def calculate_R2 ( series1, series2 ):
    r_value,p = scipy.stats.pearsonr(series1,series2)

    return r_value**2, r_value

def calculate_tau(series1, series2):
    tau = scipy.stats.kendalltau(series1, series2)
    return tau[0]

def calculate_mue( series1, series2 ):

    sumdev = 0.0
    for x in range(0,len(series1)):
        sumdev += abs( series1[x] - series2[x] )
    sumdev /= len(series1)

    #print sumdev
    return sumdev

def perturb(data):
    r""" generates new set of data based on gauss distribution
    Parameters
    ----------
    data : nd.array(shape(datapoints,2))
        first column holding actual data, second error on data

    """
    repeat = np.zeros(np.shape(data))

    count = 0
    for d in data:
        val = d[0]
        err = d[1]
        if err != 0.0:
            val2 = np.random.normal(val, err)
        else:
            val2 = val
        repeat[count][0] = val2
        repeat[count][1] = err
        count = count + 1

    return repeat

def plot_hist(edges, hist, label, color, alpha):
    halfwidth = (edges[1]-edges[0])/2
    centers= edges[:-1]+halfwidth
    fig = plt.figure(figsize=(8,4))
    plt.plot(centers, hist, color=color)
    plt.fill_between(centers, hist, facecolor=color, alpha=alpha)
    plt.xlabel(label)
    plt.ylabel('P(%s)'%label)
    sns.despine()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--input', help="Filename for relative free energies")
    parser.add_argument('-r', '--reference', help="Identifier of the reference compound")
    parser.add_argument('-o', '--output', help = "Name of output file for DDG")
    args = parser.parse_args()
    relative_DG_file = args.input
    reference = args.reference
    outfile = args.output

    Graph = nx.read_edgelist(
    relative_DG_file, delimiter=',', create_using=nx.DiGraph(),nodetype=str, data=(('weight',float),('error',float)))
    Graph = symmetrize_graph(Graph)
    pathaverage = get_average_paths(Graph, reference)
    save_average_paths(pathaverage, outfile)
