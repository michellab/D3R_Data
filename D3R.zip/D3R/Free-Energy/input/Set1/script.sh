#!/bin/bash

array=($(ls -d *))
for ((i=0; i<${#array[*]}; i++));
do
    currdir=${array[i]}
    zip $currdir/bound/SYSTEM.top.zip $currdir/bound/SYSTEM.top
    zip $currdir/free/SYSTEM.top.zip $currdir/free/SYSTEM.top
    rm $currdir/bound/SYSTEM.top
    rm $currdir/free/SYSTEM.top

done
