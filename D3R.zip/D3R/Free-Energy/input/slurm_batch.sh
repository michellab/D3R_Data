#!/bin/bash
#SBATCH -o somd-array-gpu-%A.%a.out
#SBATCH -p GTX 
#SBATCH -n 1
#SBATCH --gres=gpu:1
#SBATCH --time 24:00:00
#SBATCH --array=0-16

echo "CUDA DEVICES:" $CUDA_VISIBLE_DEVICES

lamvals=( 0.00 0.0625 0.125 0.1875 0.25 0.3125 0.375 0.4375 0.5 0.5625 0.625 0.6875 0.75 0.8125 0.875 0.9375 1 )
lam=${lamvals[SLURM_ARRAY_TASK_ID]}

echo "lambda is: " $lam

mkdir lambda-$lam
cd lambda-$lam
srun ~/sire.app/bin/somd-freenrg -C sim.cfg -c SYSTEM.crd -m MORPH.pert -t SYSTEM.top -l $lam -p CUDA
cd ..

wait
